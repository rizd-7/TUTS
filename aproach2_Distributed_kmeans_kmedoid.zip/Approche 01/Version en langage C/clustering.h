#ifndef CLUSTERING_H
#define CLUSTERING_H

#include <stddef.h> // For size_t

typedef struct {
    double *values;
    int dimension;
} Point;

// Distance functions

double manhattan_distance(const Point *a, const Point *b);
double euclidean_distance(const Point *a, const Point *b);

// Clustering algorithms
void kmeans(Point *points, size_t n_points, int k, Point *centroids, int *assignments, int max_iterations);
void kmedoids(Point *points, size_t n_points, int k, Point *medoids, int *assignments, int max_iterations);
void hybrid_kmeans_kmedoids(Point *points, size_t n_points, int n_subsets, int n_clusters, Point *medoids, int *assignments, int max_iterations);

// Utility function for reading MNIST data
Point *read_mnist_images(const char *filename, size_t *n_points);

// Silhouette score computation
double compute_silhouette_score(Point *points, size_t n_points, int k, int *assignments, double (*distance_func)(const Point *, const Point *));

#endif