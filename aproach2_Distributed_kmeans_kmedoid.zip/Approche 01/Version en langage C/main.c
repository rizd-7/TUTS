#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "clustering.h"

// Function to print cluster sizes
void print_cluster_sizes(int *assignments, size_t n_points, int k) {
    int *cluster_sizes = calloc(k, sizeof(int));
    if (!cluster_sizes) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }

    for (size_t i = 0; i < n_points; i++) {
        cluster_sizes[assignments[i]]++;
    }

    for (int i = 0; i < k; i++) {
        printf("Cluster %d: %d points\n", i, cluster_sizes[i]);
    }
    free(cluster_sizes);
}

int main() {
    // Parameters
    int k = 10;              // Number of clusters (MNIST has 10 digits)
    int n_subsets = 4;       // Number of subsets for hybrid method
    int max_iterations = 10; // Maximum iterations (reduced for faster testing)

    // Load MNIST training data
    size_t n_points;
    Point *points = read_mnist_images("train-images.idx3-ubyte", &n_points);
    if (!points) {
        fprintf(stderr, "Failed to read MNIST images\n");
        return 1;
    }
    printf("Loaded %zu images with dimension %d\n", n_points, points[0].dimension);

    // Allocate memory for centroids/medoids and assignments
    Point *centroids = malloc(k * sizeof(Point));
    Point *medoids = malloc(k * sizeof(Point));
    int *assignments = malloc(n_points * sizeof(int));
    if (!centroids || !medoids || !assignments) {
        fprintf(stderr, "Memory allocation failed\n");
        free(points);
        free(centroids);
        free(medoids);
        free(assignments);
        return 1;
    }

    // Initialize centroids and medoids
    for (int i = 0; i < k; i++) {
        centroids[i].dimension = points[0].dimension;
        medoids[i].dimension = points[0].dimension;
        centroids[i].values = malloc(points[0].dimension * sizeof(double));
        medoids[i].values = malloc(points[0].dimension * sizeof(double));
        if (!centroids[i].values || !medoids[i].values) {
            fprintf(stderr, "Memory allocation failed\n");
            for (int j = 0; j < i; j++) {
                free(centroids[j].values);
                free(medoids[j].values);
            }
            free(centroids);
            free(medoids);
            free(assignments);
            for (size_t j = 0; j < n_points; j++) {
                free(points[j].values);
            }
            free(points);
            return 1;
        }
    }

    // Set random seed for reproducibility
    srand(time(NULL));

    // 1. Run K-means
    printf("\n=== Running K-means ===\n");
    clock_t start = clock();
    kmeans(points, n_points, k, centroids, assignments, max_iterations);
    clock_t end = clock();
    double kmeans_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("K-means completed in %.2f seconds\n", kmeans_time);
    print_cluster_sizes(assignments, n_points, k);
    
    // Calculate silhouette score for K-means
    double silhouette_kmeans = compute_silhouette_score(points, n_points, k, assignments, euclidean_distance);
    printf("K-means Silhouette Index: %.4f\n", silhouette_kmeans);

    // 2. Run K-medoids
    printf("\n=== Running K-medoids ===\n");
    start = clock();
    kmedoids(points, n_points, k, medoids, assignments, max_iterations);
    end = clock();
    double kmedoids_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("K-medoids completed in %.2f seconds\n", kmedoids_time);
    print_cluster_sizes(assignments, n_points, k);
    
    // Calculate silhouette score for K-medoids
    double silhouette_kmedoids = compute_silhouette_score(points, n_points, k, assignments, manhattan_distance);
    printf("K-medoids Silhouette Index: %.4f\n", silhouette_kmedoids);

    // 3. Run Hybrid K-means/K-medoids
    printf("\n=== Running Hybrid K-means/K-medoids ===\n");
    start = clock();
    hybrid_kmeans_kmedoids(points, n_points, n_subsets, k, medoids, assignments, max_iterations);
    end = clock();
    double hybrid_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Hybrid method completed in %.2f seconds\n", hybrid_time);
    print_cluster_sizes(assignments, n_points, k);
    
    // Calculate silhouette score for hybrid method
    double silhouette_hybrid = compute_silhouette_score(points, n_points, k, assignments, manhattan_distance);
    printf("Hybrid Method Silhouette Index: %.4f\n", silhouette_hybrid);

    // Print comparison summary
    printf("\n=== Clustering Method Comparison ===\n");
    printf("Method\t\t\tTime (s)\tSilhouette Index\n");
    printf("K-means\t\t\t%.2f\t\t%.4f\n", kmeans_time, silhouette_kmeans);
    printf("K-medoids\t\t%.2f\t\t%.4f\n", kmedoids_time, silhouette_kmedoids);
    printf("Hybrid K-means/K-medoids\t%.2f\t\t%.4f\n", hybrid_time, silhouette_hybrid);

    // Cleanup
    for (int i = 0; i < k; i++) {
        free(centroids[i].values);
        free(medoids[i].values);
    }
    free(centroids);
    free(medoids);
    free(assignments);
    for (size_t i = 0; i < n_points; i++) {
        free(points[i].values);
    }
    free(points);

    return 0;
}