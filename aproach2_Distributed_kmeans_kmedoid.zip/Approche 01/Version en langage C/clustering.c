#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <stdint.h>
#include <byteswap.h>
#include "clustering.h"

#define MAX_DIMENSION 100

// Manhattan distance
double manhattan_distance(const Point *a, const Point *b) {
    double sum = 0.0;
    for (int i = 0; i < a->dimension; i++) {
        sum += fabs(a->values[i] - b->values[i]);
    }
    return sum;
}
// K-medoids implementation
void kmedoids(Point *points, size_t n_points, int k, Point *medoids, int *assignments, int max_iterations) {
    int *medoid_indices = (int*)malloc(k * sizeof(int));
    if (!medoid_indices) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }
    
    for (int i = 0; i < k; i++) {
        medoid_indices[i] = rand() % n_points;
        for (int j = 0; j < i; j++) {
            if (medoid_indices[i] == medoid_indices[j]) {
                i--;
                break;
            }
        }
    }

    int *temp_assignments = (int*)malloc(n_points * sizeof(int));
    if (!temp_assignments) {
        fprintf(stderr, "Memory allocation failed\n");
        free(medoid_indices);
        return;
    }

    for (int iter = 0; iter < max_iterations; iter++) {
        for (size_t i = 0; i < n_points; i++) {
            double min_dist = DBL_MAX;
            int best_medoid = -1;
            for (int j = 0; j < k; j++) {
                double dist = manhattan_distance(&points[i], &points[medoid_indices[j]]);
                if (dist < min_dist) {
                    min_dist = dist;
                    best_medoid = j;
                }
            }
            assignments[i] = best_medoid;
        }

        int changed = 0;
        double current_total_cost = 0.0;
        for (size_t i = 0; i < n_points; i++) {
            current_total_cost += manhattan_distance(&points[i], &points[medoid_indices[assignments[i]]]);
        }

        for (int m = 0; m < k; m++) {
            int current_medoid = medoid_indices[m];
            
            for (size_t candidate = 0; candidate < n_points; candidate++) {
                int is_medoid = 0;
                for (int j = 0; j < k; j++) {
                    if (candidate == medoid_indices[j]) {
                        is_medoid = 1;
                        break;
                    }
                }
                if (is_medoid) continue;
                
                int old_medoid = medoid_indices[m];
                medoid_indices[m] = candidate;
                
                for (size_t i = 0; i < n_points; i++) {
                    double min_dist = DBL_MAX;
                    int best_medoid = -1;
                    for (int j = 0; j < k; j++) {
                        double dist = manhattan_distance(&points[i], &points[medoid_indices[j]]);
                        if (dist < min_dist) {
                            min_dist = dist;
                            best_medoid = j;
                        }
                    }
                    temp_assignments[i] = best_medoid;
                }
                
                double total_cost = 0.0;
                for (size_t i = 0; i < n_points; i++) {
                    total_cost += manhattan_distance(&points[i], &points[medoid_indices[temp_assignments[i]]]);
                }
                
                if (total_cost < current_total_cost) {
                    current_total_cost = total_cost;
                    for (size_t i = 0; i < n_points; i++) {
                        assignments[i] = temp_assignments[i];
                    }
                    changed = 1;
                } else {
                    medoid_indices[m] = old_medoid;
                }
            }
        }

        if (!changed) break;
    }
    
    // Deep copy the medoid points to avoid pointer aliasing
    for (int i = 0; i < k; i++) {
        medoids[i].dimension = points[medoid_indices[i]].dimension;
        medoids[i].values = malloc(medoids[i].dimension * sizeof(double));
        if (!medoids[i].values) {
            fprintf(stderr, "Memory allocation failed\n");
            for (int j = 0; j < i; j++) {
                free(medoids[j].values);
            }
            free(temp_assignments);
            free(medoid_indices);
            return;
        }
        for (int d = 0; d < medoids[i].dimension; d++) {
            medoids[i].values[d] = points[medoid_indices[i]].values[d];
        }
    }
    
    free(temp_assignments);
    free(medoid_indices);
}

// Euclidean distance
double euclidean_distance(const Point *a, const Point *b) {
    double sum = 0.0;
    for (int i = 0; i < a->dimension; i++) {
        double diff = a->values[i] - b->values[i];
        sum += diff * diff;
    }
    return sqrt(sum);
}

// K-means implementation
void kmeans(Point *points, size_t n_points, int k, Point *centroids, int *assignments, int max_iterations) {
    int *prev_assign = malloc(n_points * sizeof(int));
    if (!prev_assign) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }
    
    memset(prev_assign, -1, n_points * sizeof(int));

    for (int i = 0; i < k; i++) {
        size_t idx = rand() % n_points;
        
        centroids[i].dimension = points[idx].dimension;
        centroids[i].values = malloc(centroids[i].dimension * sizeof(double));
        if (!centroids[i].values) {
            fprintf(stderr, "Memory allocation failed\n");
            free(prev_assign);
            for (int j = 0; j < i; j++) {
                free(centroids[j].values);
            }
            return;
        }
        
        for (int d = 0; d < centroids[i].dimension; d++) {
            centroids[i].values[d] = points[idx].values[d];
        }
    }

    for (int iter = 0; iter < max_iterations; iter++) {
        // Assignment step
        for (size_t i = 0; i < n_points; i++) {
            double min_dist = DBL_MAX;
            int best = 0;
            for (int j = 0; j < k; j++) {
                double d = euclidean_distance(&points[i], &centroids[j]); // Fixed: Pass address of centroids[j]
                if (d < min_dist) {
                    min_dist = d;
                    best = j;
                }
            }
            assignments[i] = best;
        }

        int changes = 0;
        for (size_t i = 0; i < n_points; i++) {
            if (assignments[i] != prev_assign[i]) {
                changes++;
            }
        }
        
        if (changes == 0) break;

        memcpy(prev_assign, assignments, n_points * sizeof(int));

        int dim = points[0].dimension;
        double **sums = malloc(k * sizeof(double*));
        int *counts = calloc(k, sizeof(int));
        
        if (!sums || !counts) {
            fprintf(stderr, "Memory allocation failed\n");
            free(prev_assign);
            if (sums) free(sums);
            if (counts) free(counts);
            return;
        }
        
        for (int j = 0; j < k; j++) {
            sums[j] = calloc(dim, sizeof(double));
            if (!sums[j]) {
                fprintf(stderr, "Memory allocation failed\n");
                for (int i = 0; i < j; i++) {
                    free(sums[i]);
                }
                free(sums);
                free(counts);
                free(prev_assign);
                return;
            }
        }

        for (size_t i = 0; i < n_points; i++) {
            int cluster = assignments[i];
            counts[cluster]++;
            for (int d = 0; d < points[i].dimension; d++) {
                sums[cluster][d] += points[i].values[d];
            }
        }

        for (int j = 0; j < k; j++) {
            if (counts[j] == 0) {
                size_t random_idx = rand() % n_points;
                for (int d = 0; d < points[random_idx].dimension; d++) {
                    centroids[j].values[d] = points[random_idx].values[d];
                }
            } else {
                for (int d = 0; d < dim; d++) {
                    centroids[j].values[d] = sums[j][d] / counts[j];
                }
            }
        }
        
        for (int j = 0; j < k; j++) {
            free(sums[j]);
        }
        free(sums);
        free(counts);
    }

    free(prev_assign);
}

// Threaded hybrid K-means/K-medoids
typedef struct {
    Point *points;
    size_t n_points;
    int k;
    Point *centroids;
    int *assignments;
    int max_iterations;
} SubsetData;

void *kmeans_thread(void *arg) {
    SubsetData *data = (SubsetData *)arg;
    kmeans(data->points, data->n_points, data->k, data->centroids, 
           data->assignments, data->max_iterations);
    return NULL;
}

typedef struct {
    int *indices;
    size_t size;
} Subset;

void shuffle(int *array, size_t n) {
    for (size_t i = n - 1; i > 0; i--) {
        size_t j = rand() % (i + 1);
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

void hybrid_kmeans_kmedoids(Point *points, size_t n_points, int n_subsets, 
                           int n_clusters, Point *medoids, int *assignments, 
                           int max_iterations) {
    srand(time(NULL));
    
    int *indices = malloc(n_points * sizeof(int));
    if (!indices) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }
    for (size_t i = 0; i < n_points; i++) {
        indices[i] = i;
    }
    shuffle(indices, n_points);

    Subset *subsets = malloc(n_subsets * sizeof(Subset));
    if (!subsets) {
        fprintf(stderr, "Memory allocation failed\n");
        free(indices);
        return;
    }
    
    size_t base_size = n_points / n_subsets;
    size_t remainder = n_points % n_subsets;
    size_t offset = 0;
    
    for (int i = 0; i < n_subsets; i++) {
        size_t subset_size = base_size + (i < remainder ? 1 : 0);
        subsets[i].indices = &indices[offset];
        subsets[i].size = subset_size;
        offset += subset_size;
    }

    Point *all_local_centroids = malloc(n_subsets * n_clusters * sizeof(Point));
    if (!all_local_centroids) {
        fprintf(stderr, "Memory allocation failed\n");
        free(subsets);
        free(indices);
        return;
    }

    pthread_t *threads = malloc(n_subsets * sizeof(pthread_t));
    SubsetData *thread_data = malloc(n_subsets * sizeof(SubsetData));
    if (!threads || !thread_data) {
        fprintf(stderr, "Memory allocation failed\n");
        free(all_local_centroids);
        free(subsets);
        free(indices);
        free(threads);
        free(thread_data);
        return;
    }

    int centroid_count = 0;
    for (int i = 0; i < n_subsets; i++) {
        thread_data[i].points = malloc(subsets[i].size * sizeof(Point));
        thread_data[i].assignments = malloc(subsets[i].size * sizeof(int));
        if (!thread_data[i].points || !thread_data[i].assignments) {
            fprintf(stderr, "Memory allocation failed\n");
            for (int j = 0; j <= i; j++) {
                free(thread_data[j].points);
                free(thread_data[j].assignments);
            }
            free(thread_data);
            free(threads);
            free(all_local_centroids);
            free(subsets);
            free(indices);
            return;
        }

        for (size_t j = 0; j < subsets[i].size; j++) {
            thread_data[i].points[j] = points[subsets[i].indices[j]];
        }
        thread_data[i].n_points = subsets[i].size;
        thread_data[i].k = n_clusters;
        thread_data[i].max_iterations = max_iterations;

        for (int j = 0; j < n_clusters; j++) {
            all_local_centroids[centroid_count + j].dimension = points[0].dimension;
            all_local_centroids[centroid_count + j].values = malloc(points[0].dimension * sizeof(double));
            if (!all_local_centroids[centroid_count + j].values) {
                fprintf(stderr, "Memory allocation failed\n");
                for (int l = 0; l <= j; l++) free(all_local_centroids[centroid_count + l].values);
                for (int l = 0; l <= i; l++) {
                    free(thread_data[l].points);
                    free(thread_data[l].assignments);
                }
                free(thread_data);
                free(threads);
                free(all_local_centroids);
                free(subsets);
                free(indices);
                return;
            }
        }
        thread_data[i].centroids = &all_local_centroids[centroid_count];
        centroid_count += n_clusters;

        if (pthread_create(&threads[i], NULL, kmeans_thread, &thread_data[i]) != 0) {
            fprintf(stderr, "Failed to create thread %d\n", i);
            for (int j = 0; j <= i; j++) {
                free(thread_data[j].points);
                free(thread_data[j].assignments);
            }
            for (int j = 0; j < centroid_count; j++) free(all_local_centroids[j].values);
            free(thread_data);
            free(threads);
            free(all_local_centroids);
            free(subsets);
            free(indices);
            return;
        }
    }

    for (int i = 0; i < n_subsets; i++) {
        pthread_join(threads[i], NULL);
        free(thread_data[i].points);
        free(thread_data[i].assignments);
    }
    free(threads);
    free(thread_data);

    int *medoid_assignments = malloc(centroid_count * sizeof(int));
    if (!medoid_assignments) {
        fprintf(stderr, "Memory allocation failed\n");
        for (int i = 0; i < centroid_count; i++) free(all_local_centroids[i].values);
        free(all_local_centroids);
        free(subsets);
        free(indices);
        return;
    }
    
    kmedoids(all_local_centroids, centroid_count, n_clusters, 
             medoids, medoid_assignments, max_iterations);
    
    for (size_t i = 0; i < n_points; i++) {
        double min_dist = DBL_MAX;
        int best_medoid = -1;
        for (int j = 0; j < n_clusters; j++) {
            double dist = manhattan_distance(&points[i], &medoids[j]);
            if (dist < min_dist) {
                min_dist = dist;
                best_medoid = j;
            }
        }
        assignments[i] = best_medoid;
    }

    for (int i = 0; i < centroid_count; i++) {
        free(all_local_centroids[i].values);
    }
    free(all_local_centroids);
    free(medoid_assignments);
    free(subsets);
    free(indices);
}

// MNIST reading functions
int32_t read_int32(FILE *fp) {
    int32_t val;
    fread(&val, sizeof(int32_t), 1, fp);
    return __bswap_32(val);
}

Point *read_mnist_images(const char *filename, size_t *n_points) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        fprintf(stderr, "Failed to open %s\n", filename);
        return NULL;
    }

    int32_t magic = read_int32(fp);
    if (magic != 2051) {
        fprintf(stderr, "Invalid magic number for images\n");
        fclose(fp);
        return NULL;
    }

    int32_t num_images = read_int32(fp);
    int32_t rows = read_int32(fp);
    int32_t cols = read_int32(fp);
    int dimension = rows * cols;

    Point *points = malloc(num_images * sizeof(Point));
    if (!points) {
        fprintf(stderr, "Memory allocation failed\n");
        fclose(fp);
        return NULL;
    }

    for (int i = 0; i < num_images; i++) {
        points[i].dimension = dimension;
        points[i].values = malloc(dimension * sizeof(double));
        if (!points[i].values) {
            fprintf(stderr, "Memory allocation failed\n");
            for (int j = 0; j < i; j++) free(points[j].values);
            free(points);
            fclose(fp);
            return NULL;
        }

        unsigned char *pixels = malloc(dimension * sizeof(unsigned char));
        if (!pixels) {
            fprintf(stderr, "Memory allocation failed\n");
            for (int j = 0; j <= i; j++) free(points[j].values);
            free(points);
            fclose(fp);
            return NULL;
        }

        fread(pixels, sizeof(unsigned char), dimension, fp);
        for (int j = 0; j < dimension; j++) {
            points[i].values[j] = (double)pixels[j] / 255.0;
        }
        free(pixels);
    }

    *n_points = num_images;
    fclose(fp);
    return points;
}

// Compute Silhouette Score
double compute_silhouette_score(Point *points, size_t n_points, int k, int *assignments, double (*distance_func)(const Point *, const Point *)) {
    if (n_points < 2 || k < 2) {
        return -1.0; // Silhouette score is not meaningful for less than 2 points or clusters
    }

    double total_silhouette = 0.0;
    size_t valid_points = 0;

    // Compute cluster sizes to check for single-point clusters
    int *cluster_sizes = calloc(k, sizeof(int));
    if (!cluster_sizes) {
        fprintf(stderr, "Memory allocation failed\n");
        return -1.0;
    }

    for (size_t i = 0; i < n_points; i++) {
        if (assignments[i] >= 0 && assignments[i] < k) {
            cluster_sizes[assignments[i]]++;
        }
    }

    for (size_t i = 0; i < n_points; i++) {
        int cluster = assignments[i];
        if (cluster < 0 || cluster >= k) continue; // Skip invalid assignments
        if (cluster_sizes[cluster] <= 1) continue; // Skip points in single-point clusters

        // Compute a(i): average distance to other points in the same cluster
        double a_i = 0.0;
        int same_cluster_count = 0;
        for (size_t j = 0; j < n_points; j++) {
            if (i == j || assignments[j] != cluster) continue;
            a_i += distance_func(&points[i], &points[j]);
            same_cluster_count++;
        }
        if (same_cluster_count > 0) {
            a_i /= same_cluster_count;
        } else {
            continue; // Shouldn't happen due to the cluster size check
        }

        // Compute b(i): minimum average distance to points in another cluster
        double b_i = DBL_MAX;
        for (int c = 0; c < k; c++) {
            if (c == cluster || cluster_sizes[c] == 0) continue; // Skip the same cluster or empty clusters
            double avg_dist = 0.0;
            int other_cluster_count = 0;
            for (size_t j = 0; j < n_points; j++) {
                if (assignments[j] != c) continue;
                avg_dist += distance_func(&points[i], &points[j]);
                other_cluster_count++;
            }
            if (other_cluster_count > 0) {
                avg_dist /= other_cluster_count;
                if (avg_dist < b_i) {
                    b_i = avg_dist;
                }
            }
        }

        // Compute silhouette score for this point
        if (b_i != DBL_MAX) {
            double s_i = (b_i - a_i) / (a_i > b_i ? a_i : b_i);
            total_silhouette += s_i;
            valid_points++;
        }
    }

    free(cluster_sizes);

    if (valid_points == 0) {
        return -1.0; // No valid points to compute silhouette score
    }

    return total_silhouette / valid_points;
}