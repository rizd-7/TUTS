#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <omp.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_statistics.h>
#include <time.h>
#include <string.h>

// Constants
#define N_POINTS 150
#define N_FEATURES 4
#define K 3
#define P 4        // Number of clients/partitions
#define ALPHA 0.05 // Compromise metric parameter

// Function to read iris.csv with class name handling
int read_iris_csv(const char *filename, gsl_matrix *X, int *y_true) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Erreur : impossible d'ouvrir %s\n", filename);
        return -1;
    }

    char line[256];
    int row = 0;

    while (fgets(line, sizeof(line), file) && row < N_POINTS) {
        double sepal_length, sepal_width, petal_length, petal_width;
        char class_name[50];
        line[strcspn(line, "\n")] = 0;

        if (sscanf(line, "%lf,%lf,%lf,%lf,%s",
                   &sepal_length, &sepal_width, &petal_length, &petal_width, class_name) != 5) {
            fprintf(stderr, "Erreur de lecture de la ligne %d: %s\n", row + 1, line);
            continue;
        }

        gsl_matrix_set(X, row, 0, sepal_length);
        gsl_matrix_set(X, row, 1, sepal_width);
        gsl_matrix_set(X, row, 2, petal_length);
        gsl_matrix_set(X, row, 3, petal_width);

        if (strcmp(class_name, "setosa") == 0 || strcmp(class_name, "Iris-setosa") == 0) {
            y_true[row] = 0;
        } else if (strcmp(class_name, "versicolor") == 0 || strcmp(class_name, "Iris-versicolor") == 0) {
            y_true[row] = 1;
        } else if (strcmp(class_name, "virginica") == 0 || strcmp(class_name, "Iris-virginica") == 0) {
            y_true[row] = 2;
        } else {
            fprintf(stderr, "Classe inconnue à la ligne %d: %s\n", row + 1, class_name);
            y_true[row] = -1;
            continue;
        }
        row++;
    }

    fclose(file);
    if (row != N_POINTS) {
        fprintf(stderr, "Erreur : nombre de lignes lues (%d) différent de N_POINTS (%d)\n", row, N_POINTS);
        return -1;
    }
    return 0;
}

// Utility functions
double euclidean(gsl_vector *a, gsl_vector *b) {
    gsl_vector *diff = gsl_vector_alloc(a->size);
    gsl_vector_memcpy(diff, a);
    gsl_vector_sub(diff, b);
    double norm;
    gsl_blas_ddot(diff, diff, &norm);
    gsl_vector_free(diff);
    return sqrt(norm);
}

// Sequential K-Medoids
gsl_vector *find_medoid(gsl_matrix *points, int n_points) {
    if (n_points == 0) {
        fprintf(stderr, "Erreur : cluster vide dans find_medoid\n");
        return NULL;
    }
    double min_sum = DBL_MAX;
    gsl_vector *best = gsl_vector_alloc(N_FEATURES);
    for (int i = 0; i < n_points; i++) {
        gsl_vector_view p = gsl_matrix_row(points, i);
        double dist_sum = 0.0;
        for (int j = 0; j < n_points; j++) {
            gsl_vector_view q = gsl_matrix_row(points, j);
            dist_sum += euclidean(&p.vector, &q.vector);
        }
        if (dist_sum < min_sum) {
            min_sum = dist_sum;
            gsl_vector_memcpy(best, &p.vector);
        }
    }
    return best;
}

// Approximate Medoid (point closest to centroid)
gsl_vector *find_approx_medoid(gsl_matrix *points, int n_points, gsl_vector *centroid) {
    if (n_points == 0) {
        fprintf(stderr, "Erreur : cluster vide dans find_approx_medoid\n");
        return NULL;
    }
    double min_dist = DBL_MAX;
    int best_idx = 0;
    for (int i = 0; i < n_points; i++) {
        gsl_vector_view p = gsl_matrix_row(points, i);
        double dist = euclidean(&p.vector, centroid);
        if (dist < min_dist) {
            min_dist = dist;
            best_idx = i;
        }
    }
    gsl_vector *medoid = gsl_vector_alloc(N_FEATURES);
    gsl_vector_view row = gsl_matrix_row(points, best_idx);
    gsl_vector_memcpy(medoid, &row.vector);
    return medoid;
}

void assign_to_medoids(gsl_matrix *X, gsl_matrix *medoids, int *labels) {
    for (int i = 0; i < X->size1; i++) {
        gsl_vector_view x = gsl_matrix_row(X, i);
        double min_dist = DBL_MAX;
        int best_medoid = 0;
        for (int j = 0; j < medoids->size1; j++) {
            gsl_vector_view m = gsl_matrix_row(medoids, j);
            double dist = euclidean(&x.vector, &m.vector);
            if (dist < min_dist) {
                min_dist = dist;
                best_medoid = j;
            }
        }
        labels[i] = best_medoid;
    }
}

gsl_matrix *select_maxmin(gsl_matrix *candidates, int k) {
    gsl_matrix *medoids = gsl_matrix_alloc(k, N_FEATURES);
    gsl_matrix *remaining = gsl_matrix_alloc(candidates->size1, N_FEATURES);
    gsl_matrix_memcpy(remaining, candidates);
    int remaining_size = candidates->size1;

    for (int i = 0; i < k; i++) {
        double best_min = -1.0;
        int best_idx = -1;
        for (int j = 0; j < remaining_size; j++) {
            gsl_vector_view cand = gsl_matrix_row(remaining, j);
            double dmin = DBL_MAX;
            if (i > 0) {
                for (int m = 0; m < i; m++) {
                    gsl_vector_view med = gsl_matrix_row(medoids, m);
                    double dist = euclidean(&cand.vector, &med.vector);
                    if (dist < dmin) dmin = dist;
                }
            } else {
                dmin = DBL_MAX;
            }
            if (dmin > best_min) {
                best_min = dmin;
                best_idx = j;
            }
        }
        gsl_vector_view best = gsl_matrix_row(remaining, best_idx);
        gsl_matrix_set_row(medoids, i, &best.vector);
        for (int j = best_idx; j < remaining_size - 1; j++) {
            gsl_vector_view src = gsl_matrix_row(remaining, j + 1);
            gsl_matrix_set_row(remaining, j, &src.vector);
        }
        remaining_size--;
    }
    gsl_matrix_free(remaining);
    return medoids;
}

void cluster_based_split(gsl_matrix *X, int *labels_global, gsl_matrix **partitions) {
    int cluster_counts[K] = {0};
    for (int i = 0; i < N_POINTS; i++) {
        cluster_counts[labels_global[i]]++;
    }

    gsl_matrix *cluster_points[K];
    int cluster_indices[K];
    for (int c = 0; c < K; c++) {
        cluster_points[c] = gsl_matrix_alloc(cluster_counts[c], N_FEATURES);
        cluster_indices[c] = 0;
    }

    for (int i = 0; i < N_POINTS; i++) {
        int c = labels_global[i];
        gsl_vector_view src = gsl_matrix_row(X, i);
        gsl_matrix_set_row(cluster_points[c], cluster_indices[c]++, &src.vector);
    }

    int points_per_client[P] = {0};
    for (int c = 0; c < K; c++) {
        int points_in_cluster = cluster_counts[c];
        int points_per_client_in_cluster = points_in_cluster / P;
        int remainder = points_in_cluster % P;
        for (int p = 0; p < P; p++) {
            points_per_client[p] += points_per_client_in_cluster + (p < remainder ? 1 : 0);
        }
    }

    for (int p = 0; p < P; p++) {
        partitions[p] = gsl_matrix_alloc(points_per_client[p], N_FEATURES);
    }

    int partition_indices[P] = {0};
    for (int c = 0; c < K; c++) {
        int points_in_cluster = cluster_counts[c];
        int points_per_client_in_cluster = points_in_cluster / P;
        int remainder = points_in_cluster % P;
        for (int p = 0; p < P; p++) {
            int points_for_p = points_per_client_in_cluster + (p < remainder ? 1 : 0);
            for (int i = 0; i < points_for_p; i++) {
                int idx = p * points_per_client_in_cluster + i;
                if (idx < points_in_cluster) {
                    gsl_vector_view src = gsl_matrix_row(cluster_points[c], idx);
                    gsl_matrix_set_row(partitions[p], partition_indices[p]++, &src.vector);
                }
            }
        }
        gsl_matrix_free(cluster_points[c]);
    }
}

double purity_score(int *y_true, int *y_pred, int n) {
    int C[K][K] = {{0}};
    for (int i = 0; i < n; i++) {
        C[y_true[i]][y_pred[i]]++;
    }
    double sum_max = 0.0;
    double total = 0.0;
    for (int j = 0; j < K; j++) {
        int max = 0;
        for (int i = 0; i < K; i++) {
            if (C[i][j] > max) max = C[i][j];
            total += C[i][j];
        }
        sum_max += max;
    }
    return sum_max / total;
}

double silhouette_score(gsl_matrix *X, int *labels) {
    int n = X->size1;
    double *a = calloc(n, sizeof(double));
    double *b = calloc(n, sizeof(double));
    int *count = calloc(K, sizeof(int));

    for (int i = 0; i < n; i++) {
        count[labels[i]]++;
    }

    for (int i = 0; i < n; i++) {
        gsl_vector_view xi = gsl_matrix_row(X, i);
        int label_i = labels[i];
        double intra_sum = 0.0;
        double nearest_sum = DBL_MAX;
        int nearest_cluster = -1;
        int intra_count = 0;

        for (int c = 0; c < K; c++) {
            double sum_dist = 0.0;
            int count_c = 0;
            for (int j = 0; j < n; j++) {
                if (labels[j] == c) {
                    gsl_vector_view xj = gsl_matrix_row(X, j);
                    sum_dist += euclidean(&xi.vector, &xj.vector);
                    count_c++;
                }
            }
            if (c == label_i) {
                intra_sum = sum_dist;
                intra_count = count_c;
            } else if (count_c > 0 && sum_dist / count_c < nearest_sum / (count[nearest_cluster] + 1e-10)) {
                nearest_sum = sum_dist;
                nearest_cluster = c;
            }
        }
        a[i] = (intra_count <= 1) ? 0.0 : intra_sum / (intra_count - 1);
        b[i] = nearest_sum / (count[nearest_cluster] + 1e-10);
    }

    double sil = 0.0;
    int valid_points = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] != 0 || b[i] != 0) {
            sil += (b[i] - a[i]) / fmax(a[i], b[i] + 1e-10);
            valid_points++;
        }
    }
    sil = valid_points > 0 ? sil / valid_points : 0.0;

    free(a);
    free(b);
    free(count);
    return sil;
}

// Sequential K-Means (standard baseline)
void kmeans(gsl_matrix *X, int k, int *labels, gsl_matrix *centers) {
    for (int i = 0; i < k; i++) {
        int idx = rand() % X->size1;
        gsl_vector_view row = gsl_matrix_row(X, idx);
        gsl_matrix_set_row(centers, i, &row.vector);
    }

    int max_iter = 100;
    int *new_labels = malloc(X->size1 * sizeof(int));
    for (int iter = 0; iter < max_iter; iter++) {
        assign_to_medoids(X, centers, new_labels);
        gsl_matrix_set_zero(centers);
        int *counts = calloc(k, sizeof(int));
        for (int i = 0; i < X->size1; i++) {
            int c = new_labels[i];
            gsl_vector_view x = gsl_matrix_row(X, i);
            gsl_vector_view center = gsl_matrix_row(centers, c);
            gsl_vector_add(&center.vector, &x.vector);
            counts[c]++;
        }
        for (int c = 0; c < k; c++) {
            if (counts[c] > 0) {
                gsl_vector_view center = gsl_matrix_row(centers, c);
                gsl_vector_scale(&center.vector, 1.0 / counts[c]);
            }
        }
        free(counts);

        int changed = 0;
        for (int i = 0; i < X->size1; i++) {
            if (new_labels[i] != labels[i]) {
                changed = 1;
                labels[i] = new_labels[i];
            }
        }
        if (!changed) break;
    }
    free(new_labels);
}

// Sequential K-Means++ for hybrid approach
void kmeans_pp_sequential(gsl_matrix *X, int k, int *labels, gsl_matrix *centers) {
    int n_points = X->size1;
    int idx = rand() % n_points;
    gsl_vector_view row = gsl_matrix_row(X, idx);
    gsl_matrix_set_row(centers, 0, &row.vector);

    double *distances = malloc(n_points * sizeof(double));
    for (int i = 1; i < k; i++) {
        double sum_dist = 0.0;
        for (int j = 0; j < n_points; j++) {
            double min_dist = DBL_MAX;
            gsl_vector_view x = gsl_matrix_row(X, j);
            for (int c = 0; c < i; c++) {
                gsl_vector_view center = gsl_matrix_row(centers, c);
                double dist = euclidean(&x.vector, &center.vector);
                if (dist < min_dist) min_dist = dist;
            }
            distances[j] = min_dist * min_dist;
            sum_dist += distances[j];
        }
        double r = ((double)rand() / RAND_MAX) * sum_dist;
        double cumsum = 0.0;
        for (int j = 0; j < n_points; j++) {
            cumsum += distances[j];
            if (cumsum >= r) {
                gsl_vector_view row = gsl_matrix_row(X, j);
                gsl_matrix_set_row(centers, i, &row.vector);
                break;
            }
        }
    }
    free(distances);

    int max_iter = 100;
    int *new_labels = malloc(n_points * sizeof(int));
    for (int iter = 0; iter < max_iter; iter++) {
        assign_to_medoids(X, centers, new_labels);
        gsl_matrix_set_zero(centers);
        int *counts = calloc(k, sizeof(int));
        for (int i = 0; i < n_points; i++) {
            int c = new_labels[i];
            gsl_vector_view x = gsl_matrix_row(X, i);
            gsl_vector_view center = gsl_matrix_row(centers, c);
            gsl_vector_add(&center.vector, &x.vector);
            counts[c]++;
        }
        for (int c = 0; c < k; c++) {
            if (counts[c] > 0) {
                gsl_vector_view center = gsl_matrix_row(centers, c);
                gsl_vector_scale(&center.vector, 1.0 / counts[c]);
            }
        }
        free(counts);

        int changed = 0;
        for (int i = 0; i < n_points; i++) {
            if (new_labels[i] != labels[i]) {
                changed = 1;
                labels[i] = new_labels[i];
            }
        }
        if (!changed) break;
    }
    free(new_labels);
}

// Optimized Client Task
void client_task(gsl_matrix *X_part, int k, gsl_matrix *medoids, double *silhouette) {
    int n_points = X_part->size1;
    int *labels = malloc(n_points * sizeof(int));
    gsl_matrix *centers = gsl_matrix_alloc(k, N_FEATURES);
    gsl_matrix *cluster_points = gsl_matrix_alloc(n_points, N_FEATURES);

    kmeans_pp_sequential(X_part, k, labels, centers);
    *silhouette = silhouette_score(X_part, labels);

    for (int c = 0; c < k; c++) {
        int count = 0;
        for (int j = 0; j < n_points; j++) {
            if (labels[j] == c) {
                gsl_vector_view row = gsl_matrix_row(X_part, j);
                gsl_matrix_set_row(cluster_points, count++, &row.vector);
            }
        }
        gsl_vector_view centroid = gsl_matrix_row(centers, c);
        gsl_vector *medoid = find_approx_medoid(cluster_points, count, &centroid.vector);
        if (medoid) {
            gsl_matrix_set_row(medoids, c, medoid);
            gsl_vector_free(medoid);
        }
    }

    free(labels);
    gsl_matrix_free(centers);
    gsl_matrix_free(cluster_points);
}

int main() {
    srand(time(NULL));

    gsl_matrix *X = gsl_matrix_alloc(N_POINTS, N_FEATURES);
    int *y_true = malloc(N_POINTS * sizeof(int));
    if (read_iris_csv("data/iris.csv", X, y_true) != 0) {
        fprintf(stderr, "Échec de la lecture de iris.csv\n");
        gsl_matrix_free(X);
        free(y_true);
        return 1;
    }

    int *labels_global = malloc(N_POINTS * sizeof(int));
    gsl_matrix *centers_global = gsl_matrix_alloc(K, N_FEATURES);
    kmeans(X, K, labels_global, centers_global);

    gsl_matrix *partitions[P];
    cluster_based_split(X, labels_global, partitions);

    // Baseline K-Means (sequential)
    double t0_km = omp_get_wtime();
    int *labels_km = malloc(N_POINTS * sizeof(int));
    gsl_matrix *centers_km = gsl_matrix_alloc(K, N_FEATURES);
    kmeans(X, K, labels_km, centers_km);
    double t_km = omp_get_wtime() - t0_km;
    double sil_km = silhouette_score(X, labels_km);
    double pur_km = purity_score(y_true, labels_km, N_POINTS);

    // Baseline K-Medoids (sequential)
    double t0_med = omp_get_wtime();
    int *labels_med = malloc(N_POINTS * sizeof(int));
    gsl_matrix *medoids_med = gsl_matrix_alloc(K, N_FEATURES);
    for (int c = 0; c < K; c++) {
        int count = 0;
        gsl_matrix *cluster_points = gsl_matrix_alloc(N_POINTS, N_FEATURES);
        for (int i = 0; i < N_POINTS; i++) {
            if (labels_km[i] == c) {
                gsl_vector_view row = gsl_matrix_row(X, i);
                gsl_matrix_set_row(cluster_points, count++, &row.vector);
            }
        }
        gsl_vector *center = find_medoid(cluster_points, count);
        if (center) {
            gsl_matrix_set_row(medoids_med, c, center);
            gsl_vector_free(center);
        }
        gsl_matrix_free(cluster_points);
    }
    assign_to_medoids(X, medoids_med, labels_med);
    double t_med = omp_get_wtime() - t0_med;
    double sil_med = silhouette_score(X, labels_med);
    double pur_med = purity_score(y_true, labels_med, N_POINTS);

    // Optimized Distributed Hybrid
    double t0_hybrid = omp_get_wtime();
    gsl_matrix *client_medoids[P];
    double client_silhouettes[P];
    for (int i = 0; i < P; i++) {
        client_medoids[i] = gsl_matrix_alloc(K, N_FEATURES);
        client_task(partitions[i], K, client_medoids[i], &client_silhouettes[i]);
    }
    double t_clients = omp_get_wtime() - t0_hybrid;

    gsl_matrix *candidates = gsl_matrix_alloc(P * K, N_FEATURES);
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < K; j++) {
            gsl_vector_view src = gsl_matrix_row(client_medoids[i], j);
            gsl_matrix_set_row(candidates, i * K + j, &src.vector);
        }
    }
    double t0_select = omp_get_wtime();
    gsl_matrix *global_medoids = select_maxmin(candidates, K);
    double t_select = omp_get_wtime() - t0_select;

    int *labels_hybrid = malloc(N_POINTS * sizeof(int));
    assign_to_medoids(X, global_medoids, labels_hybrid);
    double sil_hybrid = silhouette_score(X, labels_hybrid);
    double pur_hybrid = purity_score(y_true, labels_hybrid, N_POINTS);

    // Refinement
    double t0_ref = omp_get_wtime();
    int *labels_refined = malloc(N_POINTS * sizeof(int));
    kmeans(X, K, labels_refined, global_medoids);
    double t_ref = omp_get_wtime() - t0_ref;
    double sil_ref = silhouette_score(X, labels_refined);
    double pur_ref = purity_score(y_true, labels_refined, N_POINTS);

    double t_total_hybrid = t_clients + t_select;
    double t_total_ref = t_total_hybrid + t_ref;

    // Output results
    printf("Method\tSilhouette\tPurity\tTime(s)\tCompromise\n");
    printf("KMeans\t%.4f\t%.4f\t%.4f\t%.4f\n", sil_km, pur_km, t_km, pur_km / (1 + ALPHA * t_km));
    printf("KMedoids\t%.4f\t%.4f\t%.4f\t%.4f\n", sil_med, pur_med, t_med, pur_med / (1 + ALPHA * t_med));
    printf("Hybrid Dist\t%.4f\t%.4f\t%.4f\t%.4f\n", sil_hybrid, pur_hybrid, t_total_hybrid, pur_hybrid / (1 + ALPHA * t_total_hybrid));
    printf("Hybrid Refined\t%.4f\t%.4f\t%.4f\t%.4f\n", sil_ref, pur_ref, t_total_ref, pur_ref / (1 + ALPHA * t_total_ref));

    // Save to CSV
    FILE *fp = fopen("results.csv", "w");
    fprintf(fp, "Method,Silhouette,Purity,Time,Compromise\n");
    fprintf(fp, "KMeans,%.4f,%.4f,%.4f,%.4f\n", sil_km, pur_km, t_km, pur_km / (1 + ALPHA * t_km));
    fprintf(fp, "KMedoids,%.4f,%.4f,%.4f,%.4f\n", sil_med, pur_med, t_med, pur_med / (1 + ALPHA * t_med));
    fprintf(fp, "Hybrid Dist,%.4f,%.4f,%.4f,%.4f\n", sil_hybrid, pur_hybrid, t_total_hybrid, pur_hybrid / (1 + ALPHA * t_total_hybrid));
    fprintf(fp, "Hybrid Refined,%.4f,%.4f,%.4f,%.4f\n", sil_ref, pur_ref, t_total_ref, pur_ref / (1 + ALPHA * t_total_ref));
    fclose(fp);

        // Save cluster labels to labels.csv
    fp = fopen("labels.csv", "w");
    if (!fp) {
        fprintf(stderr, "Erreur : impossible d'ouvrir labels.csv\n");
        return 1;
    }
    fprintf(fp, "Index,KMeans,KMedoids,HybridDist,HybridRefined\n");
    for (int i = 0; i < N_POINTS; i++) {
        fprintf(fp, "%d,%d,%d,%d,%d\n", i, labels_km[i], labels_med[i], labels_hybrid[i], labels_refined[i]);
    }
    fclose(fp);

    // Cleanup
    free(y_true);
    free(labels_global);
    free(labels_km);
    free(labels_med);
    free(labels_hybrid);
    free(labels_refined);
    gsl_matrix_free(X);
    gsl_matrix_free(centers_global);
    gsl_matrix_free(centers_km);
    gsl_matrix_free(medoids_med);
    gsl_matrix_free(candidates);
    gsl_matrix_free(global_medoids);
    for (int i = 0; i < P; i++) {
        gsl_matrix_free(partitions[i]);
        gsl_matrix_free(client_medoids[i]);
    }

    return 0;
}